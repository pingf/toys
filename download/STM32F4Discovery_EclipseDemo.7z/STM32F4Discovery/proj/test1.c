/*
 * test1.c
 *
 *  Created on: 2013-8-30
 *      Author: Jesse MENG
 */

#include "stm32f4xx_conf.h"
void delay(unsigned int cnt)
{
  while(cnt--) ;
}
int main()
{
	 GPIO_InitTypeDef  GPIO_InitStructure;
	 /* GPIOD Periph clock enable */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

	  /* Configure PD12 and PD13 in output pushpull mode */
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	  GPIO_Init(GPIOD, &GPIO_InitStructure);

	  /* To achieve GPIO toggling maximum frequency, the following  sequence is mandatory.
	     You can monitor PD12 or PD13 on the scope to measure the output signal.
	     If you need to fine tune this frequency, you can add more GPIO set/reset
	     cycles to minimize more the infinite loop timing.
	     This code needs to be compiled with high speed optimization option.  */
	  while (1)
	  {
	    /* Set PD12 and PD13 */
	    GPIOD->BSRRL = GPIO_Pin_12 | GPIO_Pin_13;
	    delay(5000);
	    /* Reset PD12 and PD13 */
	    GPIOD->BSRRH = GPIO_Pin_12 | GPIO_Pin_13;
	    delay(5000);

	  }
  return 0;
}
